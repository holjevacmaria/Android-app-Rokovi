package mholjevac_20.rokovi;

import mholjevac_20.rokovi.model.Odgovor;

public interface RestSucelje {

    public void zavrseno(Odgovor odgovor);

}
